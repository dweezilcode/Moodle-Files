Slack Local Plugin
====================
Slack Local Plugin stores the userdata.

# Installation

Install the plugin from Site Administration > Plugins > Install plugins.

(or)

Add the plugin to /local/ directory.

Refresh the Moodle site, the installation will start.
  
# Settings

Site Administration > General > Slack