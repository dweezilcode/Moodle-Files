<?php

require_once('../../config.php');
require_once($CFG->libdir.'/adminlib.php');

global $CFG, $USER, $DB, $OUTPUT, $PAGE, $SITE;

$PAGE->set_url('/local/slack/chat_interface.php');
require_login();

$PAGE->set_pagelayout('admin');
$context = context_system::instance();
$PAGE->set_context($context);

admin_externalpage_setup('chatinterface');

$header = $SITE->fullname;
$PAGE->set_title('Chat Interface');
$PAGE->set_heading($header);

echo $OUTPUT->header();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatbot Moodle</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #FFFFFF; /* Changed to black */
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #333333;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .chat-box {
            background-color: #2F4F4F;
            padding: 20px;
            border-radius: 10px;
            height: 400px;
            overflow-y: scroll;
            margin-bottom: 20px;
        }

        .user-message {
            background-color: #dff0d8;
            color: #3c763d;
            border-radius: 10px;
            padding: 10px;
            margin-bottom: 10px;
        }

        .bot-message {
            background-color: #d9edf7;
            color: #31708f;
            border-radius: 10px;
            padding: 10px;
            margin-bottom: 10px;
        }

        .input-box {
            display: flex;
        }

        .input-box input[type="text"] {
            flex: 1;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-right: 10px;
        }

        .input-box button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header" style="color: white;">
            <h1>Chatbot Moodle</h1>
            <p>Your friendly AI assistant</p>
        </div>
        <div class="chat-box">
            <div class="user-message">Hello, how can I help you?</div>
            <div class="bot-message">I'm here to answer your questions!</div>
        </div>
        <div class="input-box">
            <input type="text" placeholder="Type your message...">
            <button>Send</button>
        </div>
    </div>
</body>
</html>

<?php
echo $OUTPUT->footer();
?>
