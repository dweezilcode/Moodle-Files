<?php

$string['pluginname'] = 'Slack'; // Name of your plugin.

// settings.php
$string['userdata'] = 'Userdata';
$string['usermetadata'] = 'User Metadata';
$string['chatinterface'] = 'Chat Interface';

?>
