<?php

require_once('../../config.php');
require_once($CFG->libdir.'/adminlib.php');

global $CFG, $USER, $DB, $OUTPUT, $PAGE, $SITE;

$PAGE->set_url('/local/slack/metadata.php');
require_login();

$PAGE->set_pagelayout('admin');
$context = context_system::instance();
$PAGE->set_context($context);

admin_externalpage_setup('usermetadata', '', $pageparams); // Ensure correct setup

$header = $SITE->fullname;
$PAGE->set_title(get_string('pluginname', 'local_slack'));
$PAGE->set_heading($header);

echo $OUTPUT->header();

echo '<a>Welcome to User Meta Data</a>';

echo $OUTPUT->footer();

?>
