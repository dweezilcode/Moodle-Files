<?php

defined('MOODLE_INTERNAL') || die;

if ($hassiteconfig) {

    $ADMIN->add('root', new admin_category('slack', get_string('pluginname', 'local_slack')));
	
	$ADMIN->add('slack', new admin_externalpage('userdata', get_string('userdata', 'local_slack'),
                 new moodle_url('/local/slack/userdata.php')));

    $ADMIN->add('slack', new admin_externalpage('usermetadata', get_string('usermetadata', 'local_slack'),
                 new moodle_url('/local/slack/metadata.php')));

	$ADMIN->add('slack', new admin_externalpage('chatinterface', get_string('chatinterface', 'local_slack'),
                 new moodle_url('/local/slack/chat_interface.php')));
}
?>