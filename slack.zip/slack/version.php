<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version = 2023121900;  // YYYYMMDDHH (Year Month Day 24-hr time).
$plugin->requires = 2022111800; // YYYYMMDDHH (The release version of Moodle 4.1).
$plugin->component = 'local_slack'; // Name of your plugin (used for diagnostics).

?>
